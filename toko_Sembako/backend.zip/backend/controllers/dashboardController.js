export const dashboardSummary = (req, res) => {
  res.json({
    message: "Selamat datang di Sistem Informasi Toko Sembako"
  });
};
